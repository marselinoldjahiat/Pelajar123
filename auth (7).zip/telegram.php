<?php
$id_telegram = "6809545415";
$id_botTele  = "6696946298:AAExrjK4Fnc1zXL8iGf27F_luOolaH6kbR8";
?>
